class HeadersDict(dict):
    def __init__(self, d=None):
        super().__init__()
        for k, v in dict(d or {}).items():
            self[k] = v
    def __setitem__(self, k, v):
        super().__setitem__(str(k).lower(), (str(k), v))
    def __getitem__(self, k):
        return super().__getitem__(str(k).lower())[1]
    def __contains__(self, k):
        return super().__contains__(str(k).lower())
    def __delitem__(self, k):
        super().__delitem__(str(k).lower())
    def get(self, k, d=None):
        return self[k] if k in self else d
    def items(self):
        return [(k, v) for k, v in super().values()]
    def keys(self):
        return [k for k, v in super().values()]
    def values(self):
        return [v for k, v in super().values()]
    def __iter__(self):
        return iter(self.keys())
    def __len__(self):
        return super().__len__()
    def copy(self):
        return HeadersDict(dict(self.items()))

class AWSRequest:
    def __init__(self, method=None, url=None, headers=None, data=None, params=None, auth_path=None, stream_output=False):
        self.method, self.url, self.data, self.params, self.auth_path = method, url, data, params or {}, auth_path
        self.headers = HeadersDict(headers)
        self.context = {}
    @property
    def body(self):
        b = self.data
        return b.encode("utf-8") if isinstance(b, str) else (b if b is not None else b"")
    def prepare(self):
        return self


class AWSResponse:
    pass

class AWSPreparedRequest:
    pass

class AWSRequestPreparer:
    pass

def create_request_object(*a, **k):
    raise NotImplementedError

def prepare_request_dict(*a, **k):
    raise NotImplementedError

def _urljoin(a, b, *r):
    return a.rstrip("/") + "/" + str(b).lstrip("/")

class AWSConnection:
    pass

class AWSHTTPConnection:
    pass

class AWSHTTPSConnection:
    pass

class AWSHTTPConnectionPool:
    pass

class AWSHTTPSConnectionPool:
    pass
