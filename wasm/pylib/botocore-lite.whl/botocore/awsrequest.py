class AWSRequest:
    pass

class AWSResponse:
    pass

class AWSPreparedRequest:
    pass

class HeadersDict(dict):
    pass

class AWSRequestPreparer:
    pass

def create_request_object(*a, **k):
    raise NotImplementedError

def prepare_request_dict(*a, **k):
    raise NotImplementedError

def _urljoin(a, b, *r):
    return a.rstrip("/") + "/" + str(b).lstrip("/")

class AWSConnection:
    pass

class AWSHTTPConnection:
    pass

class AWSHTTPSConnection:
    pass

class AWSHTTPConnectionPool:
    pass

class AWSHTTPSConnectionPool:
    pass
