class URLLib3Session:  # Nano: no sockets
    pass

def get_cert_path(*a, **k):
    return None

class ProxyConfiguration:
    pass
